"""EKT catalog assistant demo."""
