# EKT catalog assistant — integration demo

A single chat widget with a FastAPI backend for catalog questions, technical specifications, certificate links, stock checks, conservative alternatives, purchase terms and a confirmation-gated cart.

**The included catalog is fictional.** `DEMO-*` SKUs, prices and stock are examples, and the local cart does not connect to ekt.kz. This is a working integration starter, not a deployed EKT service.

## Run locally

Python 3.11+ is required.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. The widget works without an API key using a small offline intent router. For AI understanding of Russian and Kazakh requests, set `OPENAI_API_KEY` on the **server**. Optionally set `OPENAI_MODEL` (default `gpt-5.4-mini`). No key is sent to the browser.

```bash
export OPENAI_API_KEY="your-server-side-key"
export OPENAI_MODEL="gpt-5.4-mini"
uvicorn app.main:app --reload
```

The model returns a structured intent only. All customer-facing catalog facts are rendered from `CatalogGateway` responses. The Responses API is used through the official Python SDK; `responses.parse` constrains the intent to a Pydantic schema. No cart write function is exposed to the model.

## Try the flow

1. Ask for `DEMO-C16-OOS`. The assistant shows zero stock and the exact-key alternative `DEMO-C16-ALT`.
2. Pick the alternative and enter a quantity. The assistant displays the SKU, quantity and current price for confirmation.
3. Press **Да, добавить / Иә, қосу**, or reply explicitly in text to that proposal. Only then is the demo cart updated.
4. Ask about delivery. The response links to EKT's published terms.

In the demo, `DEMO-C10` cannot be suggested as an alternative for C16 because its current rating differs. Technical compatibility still needs review by a qualified product specialist before use.

## API

| Route | Purpose |
| --- | --- |
| `GET /api/bootstrap` | Sets an HttpOnly session cookie; returns current demo cart and pending proposal |
| `POST /api/chat` | `{"message":"...","locale":"ru"}` (`kk` also supported) |
| `POST /api/cart/propose` | `{"sku":"DEMO-C16-ALT","quantity":2,"locale":"ru"}`; no mutation |
| `POST /api/cart/confirm` | `{"pending_id":"<one-time ID>","locale":"ru"}`; commits after independent revalidation |
| `GET /api/cart` | Lists this browser's demo cart |

Requests that try to submit `price_kzt` fail validation. A proposal expires after ten minutes. If stock or price changes between proposal and confirmation, the cart is **not** updated. Another question cancels the prior proposal. The demo reserves stock on confirmed add under one process lock and shows a local demo cart link; it never starts checkout or collects payment details.

## Connect to ekt.kz

1. Implement `CatalogGateway` from `app/catalog.py` using an authorized EKT catalog/warehouse API. Map stable SKU, localized name, price in KZT, region-specific stock, technical attributes and **verified** certificate URLs. Keep certificate URL empty when none is available. Connect purchase-term answers to an approved, maintained FAQ source.
2. Implement `add_checked` as **one atomic shop operation**: fetch current product, compare the server-recorded quoted price, verify stock, add to the actual authenticated customer's cart and return the authoritative cart line. Use the shop's real cart/checkout URL in `checkout_url`. Make retries idempotent at the shop layer.
3. Replace the in-memory session registry with shared durable storage, bind it to the site's authenticated customer/session, apply rate limits and logging, and configure `PUBLIC_ORIGIN` to the exact HTTPS origin. Review regional stock and pricing semantics with EKT. Never accept a model- or client-supplied price as authoritative.
4. Serve `/api/*` and the widget assets from the same origin as the shop. Insert once in the site template:

   ```html
   <link rel="stylesheet" href="/assets/widget.css">
   <div id="ekt-assistant"></div>
   <script src="/assets/widget.js" defer></script>
   ```

   The supplied `/` page is only a visual demo. Adapt the site's content security policy and session integration to its existing application. Do not put payment fields into this widget.

The brief terms answers link to [EKT delivery/payment](https://ekt.kz/checkout-delivery/), [returns](https://ekt.kz/return/) and [ordering](https://ekt.kz/about/howto/) pages, reviewed on 2026-09-23. They avoid fixed delivery thresholds because terms differ by region and can change.

## Verify

```bash
pytest -q
```

The tests cover missing SKU, stock limits, zero-stock alternative selection, required confirmation, single-use/session-bound proposals, price override rejection, price and stock changes, Kazakh terms and concurrent demo cart adds. They exercise the actual demo cart service. A live OpenAI call and a real EKT integration require their own credentials and contract tests.
